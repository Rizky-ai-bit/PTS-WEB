<?php

class Data Extends CI_Controller{

	public function index()
	{
		$data['pasrah'] = $this->M_data->tampil_data()->result();
		$this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('data', $data);
        $this->load->view('templates/footer');
	}
}