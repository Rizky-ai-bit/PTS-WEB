<?php 

class Kyy Extends CI_Controller {

	public function index()
	{
		$this->load->model('m_kyy');
		$data['diri'] = $this->m_kyy->get_data();

		$this->load->view('v_kyy', $data);
	}

	public function tambah_aksi() 
    {
        $nama 		= $this->input->post('nama');
        $nim 		= $this->input->post('nim');
        $tgl_lahir 	= $this->input->post('tgl_lahir');
        $jk 		= $this->input->post('jk');
        $alamat     = $this->input->post('alamat');
       
        $data = array(
            'nama' 		=> $nama,
            'nim' 		=> $nim,
            'tgl_lahir' => $tgl_lahir,
            'jk' 		=> $jk,
            'alamat' 	=> $alamat
        );

        $this->M_kyy->input_data($data,'tb_profil');
        redirect('kyy/index');
    }
}
