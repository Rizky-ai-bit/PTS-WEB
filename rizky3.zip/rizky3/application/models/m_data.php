<?php

class M_data extends CI_Model{

	public function tampil_data()
	{
		return $this->db->get('tb_profil');
	}
}