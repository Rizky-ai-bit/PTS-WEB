<?php

class M_kyy extends CI_Model
{

    public function tampil_data()
    {
        return $this->db->get('tb_profil');
    }

    public function input_data($data)
    {
        $this->db->insert('tb_profil', $data);
    }
}
