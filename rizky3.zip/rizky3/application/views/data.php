<div class="contet-wrapper">
	<section class="content-header">
      <h1>
        Data Diri
      </h1>
      <ol class="breadcrumb">
      </ol>
    </section>
    <section class="content">
    	<button class="btn btn-primary"><i class="fa fa-plus"></i>Tambah Data</button>
		<table class="table">
			<tr>
				<th>NO</th>
				<th>NAMA</th>
				<th>NIM</th>
				<th>Tanggal Lahir</th>
				<th>Jenis Kelamin</th>
				<th>Alamat</th>
			</tr>

			<?php 

			$no = 1;
			foreach ($pasrah as $siswa) : ?>

			<tr>
				<td><?php echo $no++ ?></td>
				<td><?php echo $siswa->nama ?></td>
				<td><?php echo $siswa->nim ?></td>
				<td><?php echo $siswa->tgl_lahir ?></td>
				<td><?php echo $siswa->jk ?></td>
				<td><?php echo $siswa->alamat ?></td>
			</tr>
			<?php endforeach; ?>

		</table>
	</section>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">INPUT DATA</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo form_open_multipart('data/tambah_aksi'); ?>
          
          <div class="form-group">
            <label>Nama</label> 
            <input type="text" name="nama" class="form-control">
          </div>

          <div class="form-group">
            <label>NIM</label> 
            <input type="text" name="nim" class="form-control">
          </div>

          <div class="form-group">
            <label>Tanggal Lahir</label> 
            <input type="date" name="tgl_lahir" class="form-control">
          </div>

          <div class="form-group">
            <label>Jenis Kelamin</label> 
            <select type="text" name="jk">
              <option>Sistem Informasi</option>
              <option>Teknik Informatika</option>
            </select>
          </div>

          <div class="form-group">
            <label>Alamat</label> 
            <input type="text" name="alamat" class="form-control">
          </div>

          <button type="reset" class="btn btn-danger" data-dismiss="modal">Reset</button>
          <button type="submit" class="btn btn-primary">Simpan</button>

        <?php echo form_close(); ?>     
      </div>
    </div>
  </div>
</div>

</div>