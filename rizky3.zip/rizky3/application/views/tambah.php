<!--  Header End -->
<div class="container-fluid">
    <!--  Row 1 -->
    <div class="content-wrapper">

        <div class="card">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-4">Form tambah data</h5>
                <form action="<?php echo base_url('admin/tambah_aksi');?>" method="post">
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">NAMA</label>
                        <input type="text" class="form-control" name="nama" id="exampleInputEmail1">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">NIM</label>
                        <input type="text" class="form-control" name="nim" id="exampleInputPassword1">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">TANGGAL LAHIR</label>
                        <input type="date" class="form-control" name="tgl_lahir" id="exampleInputPassword1">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">JENIS KELAMIN</label>
                        <select class="form-select" name="jk" id="exampleInputPassword1">
                            <option value="" selected disabled>Pilih jenis kelamin</option>
                            <option value="Laki-laki">Laki-laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">ALAMAT</label>
                        <input type="text" class="form-control" name="alamat" id="exampleInputPassword1">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>

    </div>

</div>